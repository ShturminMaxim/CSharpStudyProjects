﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    class OrderState
    {
        public Order order;
        public OrderState(Order o)
        {
            order = o;
        }
        public virtual void AddProduct(Product p)
        {
            OperationIsNotAllowed("AddProduct");
        }

        public virtual void Register()
        {
            OperationIsNotAllowed("Register");
        }

        public virtual void Grant()
        {
            OperationIsNotAllowed("Grant");
        }

        public virtual void Ship()
        {
            OperationIsNotAllowed("Ship");
        }

        public virtual void Invoice()
        {
            OperationIsNotAllowed("Invoice");
        }

        public virtual void Cancel()
        {
            OperationIsNotAllowed("Cancel");
        }

        public void OperationIsNotAllowed(string operationName)
        {
            Console.WriteLine("Operation {0} is not allowed for Order's state {1}", operationName, this.GetType().Name);
        }
    }
}
