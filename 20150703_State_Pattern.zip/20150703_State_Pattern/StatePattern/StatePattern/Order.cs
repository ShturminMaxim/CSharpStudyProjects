﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    class Order
    {
        private OrderState state;
        private List<Product> products = new List<Product>();
        public Order()
        {
            state = new NewOrder(this);
        }
        public void SetOrderState(OrderState s)
        {
            state = s;
        }
        public void WriteCurrentStateName()
        {
            Console.WriteLine("Current Order's state: {0}", state.GetType().Name);
        }

        public void Ship()
        {
            state.Ship();
        }

        public void AddProduct(Product p)
        {
            state.AddProduct(p);
        }
        public void Register()
        {
            state.Register();
        }
        public void Grant()
        {
            state.Grant();
        }
        public void Invoice()
        {
            state.Invoice();
        }
        public void Cancel()
        {
            state.Cancel();
        }

        public void DoShipping()
        {
            Console.WriteLine("Shiping");
        }
        public void DoAddProduct( Product p)
        {
            Console.WriteLine("Adding Product");
            products.Add(p);

        }
        public void DoInvoicing()
        {
            Console.WriteLine("Invoicing");
        }
        public void DoCancel() 
        {
            Console.WriteLine("Canceling");
        }
        public void DoGranted()
        {
            Console.WriteLine("Granting");
        }
        public void DoRegistered()
        {
            Console.WriteLine("Granting");
        }


    }
}
