﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    class Granted:OrderState
    {
        public Granted(Order order)
            : base(order)
        { }

        public override void AddProduct(Product p)
        {
            order.DoAddProduct(p);
        }

        public override void Ship()
        {
            order.DoShipping();
            order.SetOrderState(new Shipped(order));
        }
        public override void Cancel()
        {
            order.DoCancel();
            order.SetOrderState(new Cancelled(order));
        }
    }
}
