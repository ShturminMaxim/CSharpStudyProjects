﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    class Registered : OrderState
    {
        public Registered(Order order)
            : base(order)
        { }

        public override void AddProduct(Product p)
        {
            order.DoAddProduct(p);
        }

        public override void Grant()
        {
            order.DoGranted();
            order.SetOrderState(new Granted(order));
        }
        public override void Cancel()
        {
            order.DoCancel();
            order.SetOrderState(new Cancelled(order));
        }
    }
}

