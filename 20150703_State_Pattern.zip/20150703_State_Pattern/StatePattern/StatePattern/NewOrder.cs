﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    class NewOrder : OrderState
    {
        public NewOrder(Order order)
            : base(order)
        { }

        public override void AddProduct(Product p)
        {
            order.DoAddProduct(p);
        }

        public override void Register()
        {
            order.DoRegistered();
            order.SetOrderState(new Registered(order));
        }
        public override void Cancel()
        {
            order.DoCancel();
            order.SetOrderState(new Cancelled(order));
        }
    }
}
