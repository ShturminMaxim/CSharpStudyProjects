﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    class Shipped:OrderState
    {
        public Shipped(Order order)
            : base(order)
        { }

        public override void Invoice()
        {
            order.DoInvoicing();
            order.SetOrderState(new Invoiced(order));
        }
    }
}
