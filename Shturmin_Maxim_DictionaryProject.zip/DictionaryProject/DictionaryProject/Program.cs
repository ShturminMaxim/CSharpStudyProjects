﻿namespace DictionaryProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary myDictionary = new Dictionary();
            
            myDictionary.InitDictionaryMenu();
        }
    }
}
